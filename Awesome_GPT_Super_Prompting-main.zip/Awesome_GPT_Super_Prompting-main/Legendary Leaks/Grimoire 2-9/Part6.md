## Part 6: Alchemy

## Chapter 17: Wizard's gotta eat!
62: 1st Dollar: Stripe Payment Links
I dare you to start an internet business with a sentence. Write code for a tip jar with a payment link using https://stripe.com/payments/payment-links or https://www.buymeacoffee.com/. Using DALLE to create a money themed background image

63: Business: Gumroad, Shopify, Stripe Atlas
Setup your own store on https://gumroad.com/ https://www.shopify.com/ https://www.lemonsqueezy.com/ or another platform. Use https://stripe.com/ or https://www.clerky.com/ or other services to incorporate a business.